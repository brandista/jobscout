ALTER TABLE `profiles` ADD `profileImage` varchar(1000);--> statement-breakpoint
ALTER TABLE `profiles` ADD `cvUrl` varchar(1000);