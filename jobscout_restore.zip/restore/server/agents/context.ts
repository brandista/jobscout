/**
 * JobScout Agent System - Context Builder
 * Builds unified context for agents from user data
 */

import type { UserContext, ProfileContext, JobContext, MatchContext, CompanyContext, EventContext } from "./types";

export async function buildUserContext(userId: number): Promise<UserContext> {
  const { 
    getProfileByUserId, 
    getSavedJobsByUserId, 
    getMatchesByUserId,
    getTopCompanyScores,
    getEventsByCompanyId 
  } = await import("../db");

  // Fetch all user data in parallel
  const [profile, savedJobsRaw, matchesRaw, companyScoresRaw] = await Promise.all([
    getProfileByUserId(userId),
    getSavedJobsByUserId(userId),
    getMatchesByUserId(userId, 20),
    getTopCompanyScores(userId, 10),
  ]);

  // Transform profile
  const profileContext: ProfileContext | null = profile ? {
    currentTitle: profile.currentTitle,
    yearsOfExperience: profile.yearsOfExperience,
    skills: safeParseArray(profile.skills),
    languages: safeParseArray(profile.languages),
    certifications: safeParseArray(profile.certifications),
    degree: profile.degree,
    field: profile.field,
    preferredJobTitles: safeParseArray(profile.preferredJobTitles),
    preferredIndustries: safeParseArray(profile.preferredIndustries),
    preferredLocations: safeParseArray(profile.preferredLocations),
    employmentTypes: safeParseArray(profile.employmentTypes),
    salaryMin: profile.salaryMin,
    salaryMax: profile.salaryMax,
    remotePreference: profile.remotePreference,
    workHistory: safeParseArray(profile.workHistory),
    targetFunctions: safeParseArray(profile.targetFunctions),
  } : null;

  // Transform saved jobs
  const savedJobs: JobContext[] = savedJobsRaw.map((sj: any) => ({
    id: sj.job.id,
    title: sj.job.title,
    company: sj.job.company,
    location: sj.job.location,
    salaryMin: sj.job.salaryMin,
    salaryMax: sj.job.salaryMax,
    employmentType: sj.job.employmentType,
    remoteType: sj.job.remoteType,
    industry: sj.job.industry,
    requiredSkills: safeParseArray(sj.job.requiredSkills),
    url: sj.job.url,
  }));

  // Transform matches
  const topMatches: MatchContext[] = matchesRaw.map((m: any) => ({
    jobId: m.job.id,
    jobTitle: m.job.title,
    company: m.job.company,
    totalScore: m.totalScore,
    skillScore: m.skillScore,
    experienceScore: m.experienceScore,
    locationScore: m.locationScore,
    matchCategory: m.matchCategory,
  }));

  // Transform company scores with events
  const recentCompanies: CompanyContext[] = await Promise.all(
    companyScoresRaw.map(async (cs: any) => {
      const events = await getEventsByCompanyId(cs.company.id, 5);
      return {
        id: cs.company.id,
        name: cs.company.name,
        industry: cs.company.industry,
        talentNeedScore: cs.score.talentNeedScore,
        profileMatchScore: cs.score.profileMatchScore,
        combinedScore: cs.score.combinedScore,
        reasons: safeParseArray(cs.score.scoreReasons),
        recentEvents: events.map((e: any): EventContext => ({
          eventType: e.eventType,
          headline: e.headline,
          summary: e.summary,
          impactStrength: e.impactStrength,
          publishedAt: e.publishedAt,
        })),
        openPositions: cs.jobs?.length || 0,
      };
    })
  );

  return {
    userId,
    profile: profileContext,
    savedJobs,
    topMatches,
    recentCompanies,
  };
}

export function formatContextForPrompt(context: UserContext): string {
  const parts: string[] = [];

  // Profile summary
  if (context.profile) {
    const p = context.profile;
    parts.push(`## Käyttäjän profiili
- Nykyinen titteli: ${p.currentTitle || "Ei määritelty"}
- Kokemus: ${p.yearsOfExperience || "?"} vuotta
- Taidot: ${p.skills.join(", ") || "Ei määritelty"}
- Kielet: ${p.languages.join(", ") || "Ei määritelty"}
- Koulutus: ${p.degree || "?"} - ${p.field || "?"}
- Tavoite tittelit: ${p.preferredJobTitles.join(", ") || "Ei määritelty"}
- Toivotut sijainnit: ${p.preferredLocations.join(", ") || "Ei määritelty"}
- Palkkatoive: ${p.salaryMin ? `${p.salaryMin}€` : "?"} - ${p.salaryMax ? `${p.salaryMax}€` : "?"}
- Etätyötoive: ${p.remotePreference || "Ei määritelty"}`);

    if (p.workHistory.length > 0) {
      parts.push(`\n### Työhistoria`);
      p.workHistory.slice(0, 3).forEach(wh => {
        parts.push(`- ${wh.title} @ ${wh.company} (${wh.duration})`);
      });
    }
  } else {
    parts.push(`## Käyttäjän profiili\nProfiilia ei ole vielä täytetty.`);
  }

  // Top matches
  if (context.topMatches.length > 0) {
    parts.push(`\n## Parhaat työpaikkamatchit (top ${context.topMatches.length})`);
    context.topMatches.slice(0, 5).forEach(m => {
      parts.push(`- ${m.jobTitle} @ ${m.company} - Score: ${m.totalScore}% (${m.matchCategory || "?"})`);
    });
  }

  // Saved jobs
  if (context.savedJobs.length > 0) {
    parts.push(`\n## Tallennetut työpaikat (${context.savedJobs.length} kpl)`);
    context.savedJobs.slice(0, 5).forEach(j => {
      const salary = j.salaryMin && j.salaryMax 
        ? `${j.salaryMin}-${j.salaryMax}€` 
        : "Palkka ei tiedossa";
      parts.push(`- ${j.title} @ ${j.company} (${j.location || "?"}) - ${salary}`);
    });
  }

  // Companies with signals
  if (context.recentCompanies.length > 0) {
    parts.push(`\n## Kiinnostavat yritykset signaalien perusteella`);
    context.recentCompanies.slice(0, 5).forEach(c => {
      parts.push(`- ${c.name} (${c.industry || "?"}) - Score: ${c.combinedScore || "?"}%`);
      if (c.recentEvents.length > 0) {
        parts.push(`  Viimeisimmät signaalit:`);
        c.recentEvents.slice(0, 2).forEach(e => {
          parts.push(`  • [${e.eventType}] ${e.headline}`);
        });
      }
    });
  }

  return parts.join("\n");
}

function safeParseArray(value: any): any[] {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
